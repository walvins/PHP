<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Datos</title>
</head>
<body>
    <?php
        $datos=array(array("11111111", "Martin Alvaro","22/10/1997","Burgos","Quintanadueñas"),
        array("22222222", "Perez Raul","27/04/1999","Avila","Puebloinventado"),
        array("33333333", "Esteban Raul","24/11/1990","Burgos","Cardeñadijo"),
        array("44444444", "Mueriel Maria","13/12/2000","Caceres","Cambron"),
        array("55555555", "Ape Nombre","24/11/2003","Avila","OtroPueblo"));

        $cabecera=array("dni","nombre y apellidos","fechanac","provincia","localidad");
    ?>
</body>
</html>